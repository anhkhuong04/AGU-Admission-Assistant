# AGU Admission Assistant — Product Overview

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Cập nhật | 2026-11-08 |
| Chủ sở hữu quyết định | Product Owner (người phát triển dự án) |
| Trạng thái | Chưa được Trường Đại học An Giang phê duyệt hoặc bảo trợ |
| Phạm vi | Tuyển sinh **đại học chính quy** tại Trường Đại học An Giang (AGU) |

## 1. Executive summary

**AGU Admission Assistant** là website độc lập hỗ trợ thí sinh và phụ huynh tra cứu, hiểu và đối chiếu thông tin tuyển sinh đại học chính quy của AGU bằng hội thoại AI và các trang tra cứu có cấu trúc. Hệ thống tổng hợp **chỉ từ nguồn công khai được kiểm chứng**, có trích dẫn, phân biệt năm/đợt tuyển sinh, có cơ chế từ chối khẳng định khi thiếu bằng chứng và có dashboard để quản lý tri thức.

Sản phẩm ban đầu là **bên thứ ba, không chính thức**. Mục tiêu dài hạn là chứng minh độ tin cậy, năng lực vận hành và giá trị nghiệp vụ để có thể đề xuất hợp tác/triển khai cho nhà trường; đây **không** phải cam kết AGU sẽ tiếp nhận.

## 2. Problem statement và cơ hội

| Vấn đề giả định cần kiểm chứng | Hệ quả | Giá trị sản phẩm |
|---|---|---|
| Thông tin phân tán ở trang ngành, tin tức và PDF | Khó tìm đúng câu trả lời | Tìm kiếm thống nhất, trích dẫn nguyên nguồn |
| Nội dung thay đổi theo năm, đợt, quyết định bổ sung | Dễ dùng thông tin hết hiệu lực | Lọc năm/đợt, trạng thái hiệu lực, quản lý phiên bản |
| Ngôn ngữ thông báo mang tính hành chính | Thí sinh khó hiểu điều kiện và các bước | Diễn giải rõ ràng, hướng dẫn từng bước |
| Không biết nên xem ngành nào | Tốn thời gian tìm hiểu nhiều ngành | Khám phá/so sánh ngành trên dữ liệu xác minh |
| Câu hỏi không có dữ liệu được công bố | Nguy cơ chatbot bịa câu trả lời | Abstention, gợi ý nguồn liên hệ chính thức |

**Bằng chứng bối cảnh:** Cổng tuyển sinh công khai có thông tin năm 2026, thông báo bổ sung theo đợt và tài liệu đính kèm PDF/DOCX. Điều này xác nhận bài toán *đa nguồn + biến động theo thời gian*, nhưng **chưa xác nhận** mức độ khó khăn thực tế hoặc nhu cầu sử dụng; cần khảo sát người dùng.

## 3. Vision, mission, positioning

- **Vision:** Trợ lý số đáng tin cậy cho việc tìm hiểu thông tin tuyển sinh AGU.
- **Mission:** Rút ngắn hành trình từ câu hỏi đến thông tin có bằng chứng và hành động tiếp theo.
- **Positioning:** *Evidence-first admission assistant*, không phải chatbot trò chuyện đa mục đích, không phải cổng đăng ký xét tuyển.
- **Core promise:** Trả lời có nguồn và đúng ngữ cảnh thời gian; khi chưa có căn cứ thì nói rõ giới hạn.

## 4. Người dùng và stakeholders

| Nhóm | Mục tiêu cốt lõi | Ghi chú |
|---|---|---|
| Thí sinh THPT / thí sinh tự do | Tìm ngành, phương thức, mốc thời gian, hồ sơ | Primary user; mobile-first |
| Phụ huynh | Học phí, lộ trình, chính sách hỗ trợ | Primary user |
| Quản trị nội dung | Xem/sửa/xác minh nguồn, phát hành tri thức | Trước hợp tác: chủ dự án, **không giả định** là cán bộ AGU |
| Người phát triển/vận hành | Đo chất lượng, phát hiện lỗi, kiểm soát chi phí | Một developer + AI coding agent |
| Bộ phận tuyển sinh AGU (tương lai) | Thông tin chính xác, có quy trình quản trị | Stakeholder tiềm năng; chưa tham gia |

### Jobs-to-be-done

1. “Khi chuẩn bị đăng ký, tôi muốn biết điều kiện/phương thức đúng năm để không bỏ sót bước.”
2. “Khi phân vân giữa các ngành, tôi muốn so sánh thông tin chính thức để tự quyết định.”
3. “Khi thấy thông báo mới, tôi muốn biết thay đổi nào áp dụng cho mình, dựa trên tài liệu nào.”
4. “Khi chatbot không chắc, tôi muốn được hướng tới nguồn chính thức thay vì nhận thông tin phỏng đoán.”

## 5. Product boundaries

### In scope — MVP

- Website public responsive, tra cứu bằng hội thoại tiếng Việt, không bắt buộc tài khoản.
- Hỏi đáp tuyển sinh đại học **chính quy** trên nguồn AGU công khai được duyệt.
- RAG retrieval, citation đến URL/tài liệu/trang; chọn năm tuyển sinh khi cần.
- Chính sách trả lời thiếu bằng chứng, thông tin xung đột, câu hỏi ngoài phạm vi.
- Admin đăng nhập: ingest/preview/review/publish/unpublish tài liệu.
- Bộ eval cố định, logging đã giảm thiểu dữ liệu cá nhân, giới hạn truy cập/chi phí.
- Banner/disclaimer liên tục phân biệt dự án độc lập và kênh chính thức.

### In scope — sau MVP

- Trang khám phá ngành và so sánh từ dữ liệu có cấu trúc đã kiểm duyệt.
- Hướng dẫn nhiều bước cho quy trình đăng ký; feedback và dashboard nâng cao.
- Phát hiện tài liệu mới, xử lý phiên bản tự động có người duyệt.

### Out of scope — không tự triển khai

- Tuyển sinh sau đại học, vừa làm vừa học, liên thông, đào tạo ngắn hạn (trừ khi sau này mở rộng bằng quyết định riêng).
- Nộp hồ sơ, đăng nhập tài khoản tuyển sinh AGU, tra cứu dữ liệu nội bộ hoặc kết quả cá nhân.
- Xác nhận chính thức “đủ điều kiện”, “đậu/rớt”, dự đoán điểm chuẩn hoặc bảo đảm trúng tuyển.
- Thu thập CCCD, học bạ, bảng điểm, số điện thoại mặc định; tự liên hệ người dùng.
- Nhân danh AGU, dùng thương hiệu như một sản phẩm đã được trường phê duyệt.

## 6. Nguyên tắc không thể thương lượng

1. **Nguồn và thời gian trước độ trôi chảy:** Mọi khẳng định tuyển sinh quan trọng phải có dẫn chứng đúng năm/đợt.
2. **Không đủ căn cứ thì không kết luận:** Dữ liệu 2026 không được dùng để khẳng định quy định 2027.
3. **Published knowledge only:** Chỉ dữ liệu đã duyệt mới phục vụ người dùng public; không nạp tài liệu lỗi ngay vào production.
4. **Structured facts ≠ vector chunks:** Mã ngành, tổ hợp, chỉ tiêu, học phí, thời hạn được quản lý có cấu trúc khi cần truy vấn chính xác.
5. **Human control:** Người quản trị có thể thu hồi nguồn, rollback bản phát hành và xem dấu vết trả lời.
6. **Privacy by default:** Chat công khai không yêu cầu thông tin định danh; loại bỏ dữ liệu nhạy cảm khỏi logs.
7. **Progressive delivery:** Chứng minh chất lượng tìm kiếm và ingestion trước khi xây UX tư vấn mở rộng.

## 7. North Star, KPIs và guardrails

**North Star đề xuất:** Tỷ lệ *verified task resolution*: tỷ lệ phiên mà người dùng hoàn thành tác vụ có phản hồi xác nhận, đồng thời câu trả lời được kiểm tra có bằng chứng đúng.

| Chỉ số | Ngưỡng đề xuất cho pilot | Cách đo / giới hạn |
|---|---:|---|
| Accuracy trên tập hỏi đáp chuẩn | ≥95% | Human-evaluated; phân nhóm theo rủi ro |
| Citation support correctness | ≥98% | Mẫu câu trả lời và nguồn thực sự hỗ trợ câu |
| Abstention correctness | ≥95% | Tập câu hỏi ngoài tài liệu/chưa công bố |
| Recall@5 | ≥90% | Gold evidence trên retrieval set |
| User task completion | ≥85% | Nghiên cứu tác vụ; không suy ra từ số message |
| P95 time-to-first-token | ≤3 giây | Theo tải và hạ tầng pilot |
| Uptime | ≥99,5%/tháng | Mục tiêu, không phải SLA đã cam kết |

Các ngưỡng trên là **proposal cần hiệu chỉnh qua benchmark**, không phải thành tích đã đạt. Không đánh đổi độ đúng để tăng completion. Nhóm dữ liệu nhạy với năm, hạn chót, học phí có thể yêu cầu tiêu chuẩn kiểm định cao hơn.

## 8. Rủi ro kinh doanh/vận hành

| Rủi ro | Mức | Phản ứng |
|---|---|---|
| Không có quyền dữ liệu nội bộ/hỗ trợ từ AGU | Cao | Chỉ sử dụng dữ liệu công khai, scope rõ, citation, không giả mạo chính thức |
| Tài liệu mới thay đổi nguồn cũ | Cao | Source versioning, supersession, review + regression eval |
| OCR/bảng PDF sai số liệu | Cao | Quality gates và duyệt từng trường quan trọng |
| LLM tạo khẳng định sai | Cao | Grounding, abstention, rule-based routing, eval |
| Lạm dụng API tăng chi phí | Trung bình–cao | Rate limit, token cap, quota, budget alarm |
| Một người phát triển quá tải | Trung bình–cao | Scope P0, vertical slices, không chạy theo nhiều framework |
| Hiểu nhầm dự án là kênh AGU chính thức | Cao | Disclaimer, thương hiệu riêng, link kênh chính thức |

## 9. Giả định, quyết định và câu hỏi chờ review

**Đã chốt với Product Owner:** đại học chính quy; website độc lập; chưa được AGU bảo trợ; mục tiêu đề xuất triển khai thực tế; phát triển bởi một người và AI coding agent.

**Đề xuất chưa chốt:** tên/branding công khai; năm dữ liệu đầu tiên (đề xuất 2026 và bổ sung 2027 khi có nguồn); KPI pilot; chi phí vận hành; công nghệ theo ADR-001; lưu hội thoại ở chế độ không đăng nhập.

**Cần xác minh trước public pilot:** quyền sử dụng nội dung và logo; kênh liên hệ chính thức phù hợp; thời gian lưu dữ liệu; quy trình xử lý yêu cầu gỡ/cập nhật thông tin; khảo sát nhu cầu 5–10 thí sinh/phụ huynh.

## 10. Nguồn bối cảnh chính thức (xem/nghiệm thu lại khi triển khai)

- https://tuyensinh.agu.edu.vn/
- https://tuyensinh.agu.edu.vn/tin-tuc?tag=Tuy%E1%BB%83n+sinh+2026
- https://tuyensinh.agu.edu.vn/tin-tuc/quyet-dinh-ban-hanh-thong-tin-tuyen-sinh-dai-hoc-hinh-thuc-dao-tao-chinh-quy-hinh-thuc-dao-tao-thuong-xuyen-nam-2026-cua-truong-dai-hoc-an-giang-cap-nhat-3-nganh-moi

## 11. Related documents

- [`02-prd.md`](02-prd.md): chi tiết yêu cầu/tiêu chí nghiệm thu.
- [`03-system-architecture.md`](03-system-architecture.md): ranh giới module và hạ tầng.
- [`04-ai-rag-architecture.md`](04-ai-rag-architecture.md), [`05-data-architecture.md`](05-data-architecture.md): logic chứng cứ và quản trị dữ liệu.

