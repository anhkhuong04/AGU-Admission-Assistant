# AGU Admission Assistant — System Architecture

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Kiến trúc | Modular monolith + asynchronous ingestion worker |
| Technology decision | Đề xuất tại [`ADR-001`](decisions/ADR-001-technology-stack.md), chưa phê duyệt |

## 1. Architecture drivers

1. **Correctness/traceability:** Answer phải truy về document version và section/page.
2. **Isolation:** Không lẫn tài liệu draft/rejected với published; public không được gọi admin.
3. **Changeability:** Thay LLM/embedding/parser mà không viết lại domain model.
4. **Solo-engineer operability:** Giảm số service độc lập; ưu tiên PostgreSQL và worker riêng.
5. **Future institutional deployment:** Hỗ trợ đa vai trò, audit và content workflow ngay từ thiết kế.

## 2. C4 — System Context (logical)

```mermaid
flowchart LR
  U["Thí sinh / Phụ huynh"] --> W["AGU Assistant Web"]
  A["Content Admin"] --> W
  W --> S["Backend API"]
  S --> L["LLM / Embedding Provider"]
  S --> P["Published AGU Sources"]
  S --> DB[("App + Knowledge DB")]
```

`Published AGU Sources` là nguồn tham chiếu công khai, **không phải API được AGU tài trợ hoặc bảo đảm**. Link crawler chỉ nên chạy trên allowlist, theo điều kiện truy cập hiện hành và giới hạn tải.

## 3. Container view và luồng dữ liệu

```mermaid
flowchart TB
  WEB["Next.js Website / Admin"] --> API["FastAPI REST + SSE"]
  API --> AI["AI Service / Query Router"]
  API --> ADM["Content & Review Service"]
  AI --> PG[("PostgreSQL + pgvector")]
  AI --> MODEL["LLM/Embedding/Reranker adapters"]
  ADM --> PG
  ADM --> Q["Ingestion Job Queue"]
  Q --> WORKER["Python ingestion worker"]
  WORKER --> RAW["Immutable raw object storage"]
  WORKER --> PG
```

**MVP deployment units:** frontend, API, worker, managed PostgreSQL, private object storage; job queue có thể khởi đầu từ bảng `ingestion_jobs` + worker polling có khóa an toàn. Chỉ thêm Redis/queue chuyên biệt khi có bằng chứng tải hoặc nhu cầu retry/throughput. Database migrations chạy như tác vụ release, không tự chạy đồng thời từ nhiều replicas.

## 4. Logical modules / ownership

| Module | Trách nhiệm | Không được làm |
|---|---|---|
| `conversation` | Session context, request/response, feedback | Quyết định validity của nguồn |
| `query_router` | Intent/entity/year extraction; structured vs retrieval | Thực thi arbitrary SQL do LLM viết |
| `retrieval` | Dense + lexical, filters, RRF, rerank, source evidence | Đọc unpublished/draft khi trả public |
| `answering` | Grounded generation, citation rendering, abstention | Dựng citation URL từ văn bản LLM |
| `content` | Document/version, review, publish/unpublish | Tự phê duyệt từ OCR confidence |
| `ingestion` | Download, parse, validate, chunk, embed, index | Publish bản chưa duyệt |
| `admission_facts` | API đọc facts đã duyệt: ngành, tổ hợp, mốc | Dùng fact không có provenance |
| `evaluation` | Golden sets, runs, score/regression | Ghi đè ground truth do LLM tự tạo |
| `identity` | Admin auth/roles, audit | Tin role do client tự gửi |
| `observability` | Trace, log mask, usage/cost | Log raw PII hoặc secrets |

Phân lớp: `presentation -> application -> domain -> infrastructure`. Module gọi qua interface/service; các lớp domain không import trực tiếp SDK provider.

## 5. API design — versioned contracts

Prefix `/api/v1`; error envelope gồm `code`, `message`, `request_id`, `details?`; validation error trả 4xx, transient dependency failure trả 503. API public hỗ trợ SSE streaming với event typed và có phương án nonstreaming để test.

| Endpoint | Auth | Input / output cốt lõi |
|---|---|---|
| `POST /chat` | Public + throttling | `message`, `conversation_id?`, `academic_year?` → answer/status/evidence |
| `POST /chat/stream` | Public + throttling | SSE: `started`, `evidence`, `delta`, `completed`, `error` |
| `GET /public/years` | Public | Năm có nội dung đã publish |
| `GET /public/majors` | Public (P1) | Các ngành theo năm, paginate/filter |
| `GET /public/documents/{id}` | Public | Metadata/nguồn công khai của bản published |
| `POST /admin/sources` | Admin | URL/upload + provenance; trả `job_id` |
| `GET /admin/ingestion-jobs/{id}` | Admin | Stage, warnings/errors, retryability |
| `POST /admin/versions/{id}/approve` | Reviewer/admin | Approval record; actor ID từ server |
| `POST /admin/versions/{id}/publish` | Publisher/admin | Atomic publish bản index-ready |
| `POST /admin/versions/{id}/unpublish` | Publisher/admin | Ngăn retrieval public ngay |
| `POST /admin/evaluations/runs` | Admin | Eval dataset/version/metrics |
| `GET /health/live`, `/health/ready` | Infrastructure | Liveness vs readiness riêng |

### Public answer contract (illustrative)

```json
{
  "request_id": "req_...",
  "conversation_id": "conv_...",
  "status": "answered",
  "answer": "Nội dung đã được chứng thực...",
  "academic_year": 2026,
  "citations": [{
    "evidence_id": "ev_...",
    "document_version_id": "uuid",
    "title": "Tên văn bản",
    "source_url": "https://tuyensinh.agu.edu.vn/...",
    "page": 8,
    "section": "Mục 2"
  }],
  "follow_up_questions": []
}
```

Ví dụ chỉ mô tả schema; không phải nội dung tuyển sinh thực tế. Các trạng thái: `answered | clarification_needed | insufficient_evidence | conflicting_sources | out_of_scope | service_unavailable`.

## 6. Security architecture

- **Public:** no auth, per-IP + anonymous-session throttling, bot abuse limit, request/token cap, CORS origin allowlist, CSRF controls phù hợp session/cookie.
- **Admin:** auth trên server, MFA nếu nhà cung cấp hỗ trợ; roles `admin`, `reviewer`, `publisher` (MVP một account có thể mang nhiều role nhưng vẫn kiểm tra quyền).
- **Secrets:** chỉ backend/worker; môi trường server-managed, rotate; không đưa vào frontend, prompt, logs.
- **Upload:** allowlist MIME/magic bytes, max size/pages, sandbox parser, không thực thi macro, không fetch URL tùy ý (chống SSRF), antivirus nếu cần.
- **Provider trust:** raw HTML/PDF và retrieved chunks là untrusted input; giới hạn model tool permissions; output được escape trước khi render.
- **Data protection:** chỉ ghi metadata/log an toàn; retention có cấu hình; backup DB và object storage được kiểm tra restore.
- **Untrusted URLs:** crawler allowlist tên miền và redirect targets, giới hạn kích thước/tốc độ/thời gian.

## 7. Reliability & consistency

**Data publish invariants:**

1. Version phải `approved`, QA passed và embeddings/indices đã sẵn sàng trước `publish`.
2. Publication là transaction đổi trạng thái/active pointer; không phát hành dở dang.
3. Khi unpublish, retrieval kiểm tra current status tại query time; không chỉ tin cache cũ.
4. Jobs retry idempotent bằng `(source_id, checksum, parser_version, embedding_version)`; không nhân đôi vectors.
5. Nguồn bị thay thế chỉ khi curator phê duyệt mối quan hệ `supersedes`.

**Fallback:** LLM timeout → `service_unavailable`; không đủ evidence → `insufficient_evidence`; PostgreSQL unavailable → fail closed với admin/public; ingestion thất bại → vẫn giữ bản published trước đó. Circuit breaker/timeout/retry with jitter tại provider boundary; không retry generation không giới hạn.

## 8. Observability và vận hành

- `request_id` xuyên suốt frontend/API/retrieval/provider; `job_id` cho ingestion.
- Logs có cấu trúc: status, latency stage, model IDs, token usage, chi phí ước tính, số evidence, lỗi; **không** lưu raw sensitive data mặc định.
- Metrics: TTFT/total latency p50/p95, error rate, rate-limit count, RAG abstention, retrieval hit, OCR warnings, publish frequency, cost/day.
- Alerts: budget threshold, sustained 5xx, worker backlog, ingestion failure burst, stale content, recall/eval regression.
- Health checks và runbooks: provider outage, DB restore, rollback index, secret rotation.

## 9. CI/CD and environments

- Environments: `local`, `staging`, `production`; mỗi môi trường có database/object store riêng.
- CI: lint/type/static checks, unit/integration, database migration test, API contract, security/dependency scan.
- Staging: sample/test data, no production credentials; smoke test chat + upload/review/publish + rollback.
- Release: migrations backward-compatible -> deploy API/worker -> smoke -> promote; feature flags cho modules P1.
- Infrastructure as Code khi ổn định; chưa cần Kubernetes/microservices.

## 10. Assumptions / ADR linkage

- **Proposed:** FastAPI + Next.js + PostgreSQL/pgvector + Docling + LlamaIndex selective usage.
- **Unresolved:** Hosting provider, object storage provider, identity implementation, LLM/embedding/reranker models, monthly budget.
- Chi tiết nguồn tri thức: [`05-data-architecture.md`](05-data-architecture.md); retrieval policy: [`04-ai-rag-architecture.md`](04-ai-rag-architecture.md).
- Technology decision log: [`decisions/ADR-001-technology-stack.md`](decisions/ADR-001-technology-stack.md).

