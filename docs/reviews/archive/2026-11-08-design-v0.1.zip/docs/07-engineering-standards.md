# AGU Admission Assistant — Engineering Standards

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Áp dụng | Frontend, API, worker, data migrations, AI eval, CI/CD |
| Người duyệt thay đổi quan trọng | Product Owner |

## 1. Engineering principles

1. **Implement documented contracts:** Mã nguồn không đi ngược PRD/ADR; thay đổi thiết kế có ảnh hưởng → cập nhật tài liệu trước/đồng thời.
2. **Vertical slices:** Mỗi task có backend/API/UI/test hoặc artifact đủ để demo một luồng thực.
3. **Source integrity:** Không sử dụng dữ liệu tuyển sinh tự bịa làm dữ liệu công khai; fixtures ghi `SYNTHETIC`.
4. **Least privilege:** Public API chỉ đọc knowledge đã publish; admin mutations có RBAC/audit.
5. **Observable by design:** Ghi lại request/job IDs, stage, latency, chi phí, mã lỗi.
6. **Reproducible:** Pin versions, migrations, deterministic eval inputs, idempotent ingestion.
7. **Small, testable abstractions:** Wrapper ở provider boundaries; không tạo nhiều microservices/agents không cần thiết.

## 2. Proposed repository structure

```text
/
  AGENTS.md                    # Tạo khi khởi tạo repo; chỉ định hướng/điều hướng docs
  README.md
  docs/
    01-product-overview.md ... 08-implementation-roadmap.md
    decisions/ADR-001-technology-stack.md
  apps/web/                    # Next.js app + public/admin routes
  services/api/                # FastAPI app, domain/services/repositories
  services/worker/             # Ingestion jobs and parsers
  packages/contracts/          # OpenAPI generated client/types, optional
  infra/                       # Docker Compose, deployment, migrations
  tests/
    fixtures/                  # Synthetic docs/PDF/HTML, explicitly labeled
    e2e/
    evals/                     # Gold dataset + metrics definitions
  .github/workflows/           # CI
```

**Source of truth:** `docs/02-prd.md` cho nghiệp vụ; `03`/`04`/`05` cho thiết kế; `ADR-001` cho stack. `AGENTS.md` không lặp nguyên tài liệu mà trỏ đến mục liên quan.

## 3. Coding standards

### Python/backend/worker

- Python 3.x bản được chọn và khóa tại implementation; dùng type hints, Pydantic schemas, FastAPI dependency injection tại boundary.
- Formatter/linter: Ruff; static types: mypy hoặc pyright (chọn một và CI enforce); pytest cho test.
- Tách `domain`, `application`, `infrastructure`, `presentation`; domain không import trực tiếp LlamaIndex/LLM SDK/DB driver.
- Dùng async cho I/O HTTP/provider/DB khi phù hợp; parsing CPU-heavy chạy worker, không block API event loop.
- Dependency injection cho clock, LLM, embedding, storage, repositories để test offline.
- Explicit exceptions (`ParseError`, `UnverifiedSource`, `ProviderTimeout`, `InsufficientEvidence`); không `except Exception: pass`.
- SQL migrations qua Alembic; parameterized queries, không text-to-SQL tùy ý.

### TypeScript/frontend

- TypeScript strict; ESLint/Prettier; không dùng `any` để né lỗi contract.
- React components tách UI primitives, domain components, page orchestration; API client từ OpenAPI contract khi ổn định.
- Form validation ở cả client và server; UI không suy đoán role/status từ data có thể sửa.
- Error/loading/empty states là phần bắt buộc của mọi trang; không hardcode fake business data.
- Semantic HTML, keyboard tests và accessibility lint/checks.

### Naming, IDs, time

- DB tables/columns `snake_case`, Python `snake_case`, TypeScript `camelCase`/components `PascalCase`.
- Entity IDs UUID; `request_id`, `job_id` dùng trong logs; strings user-facing được localized.
- Timestamps lưu UTC và timezone-aware; thời hạn tuyển sinh hiển thị theo timezone Việt Nam (`Asia/Ho_Chi_Minh`).
- `academic_year` là năm xét tuyển, **không** lấy từ timestamp hiện tại khi không có tài liệu.

## 4. API and schema contracts

- Version `/api/v1`; request/response Pydantic/OpenAPI; thay đổi breaking cần versioning hoặc migration plan.
- Status riêng cho domain result (`insufficient_evidence`, `conflicting_sources`) không đánh đồng 200/4xx/5xx.
- Public citations chứa safe source IDs/links, không expose storage path, internal prompt hoặc raw provider logs.
- Pagination, filtering, size limits cho list/admin APIs; uploads qua content-type/magic bytes/file-size checks.
- Idempotency key cho ingestion retry và mutation dễ bị gửi lặp; ghi audit user/time/reason.

## 5. Database & ingestion standards

- **Migration first:** schema change bắt buộc kèm migration forward và kế hoạch rollback/phục hồi.
- `raw` immutable, phiên bản có checksum/parser/model config; review/publish là state transitions có authorization.
- Cấm hard-delete dữ liệu published đang được trích dẫn mà không có kế hoạch audit/retention.
- Embedding model/version/dimension là một phần identity index; thay model phải re-index và đo regression.
- Quản trị viên cần preview bảng và metadata trước khi approved; parser không tự chứng thực facts.
- Đọc/ghi DB qua repositories; public query luôn scope vào published snapshot đã chọn.

## 6. AI engineering standards

- Mỗi prompt template có version, output JSON schema và các test cho refusal/citation/time-awareness.
- LLM output là untrusted; validate schema và mapping citation IDs ở server.
- Không để external page/PDF chỉ đạo system prompt, gọi privileged tools hoặc định nghĩa policy.
- Gold dataset được version hóa; thay chunking, retrieval params, embedding, model hoặc prompt chạy eval tương ứng.
- Eval reports ghi source snapshot/index version/model IDs, sample size, error categories, cost/latency.
- Không quyết định chọn model chỉ bằng subjective demo; benchmark trên tiếng Việt và tập AGU.

## 7. Automated test pyramid

| Level | Đối tượng | Minimum CI gate |
|---|---|---|
| Unit | Date/year rules, parser normalizers, filters, RRF, citation validator | Không cần network/API thực |
| Integration | API ↔ DB, migrations, storage, ingestion job, publish/rollback | Test DB riêng + fixtures |
| Contract | OpenAPI schemas, frontend API client, SSE events | Breaking changes fail CI |
| E2E | Ask → source; upload → review → publish → rollback; auth | Playwright/available runner |
| AI eval | Recall/citation/abstention/temporal correctness | Regression run trước mỗi AI release |
| Security | RBAC, XSS, prompt injection, SSRF, uploads, rate limits | Must-pass critical scenarios |

Không ép unit coverage % cao khi chưa có domain behavior; ưu tiên branch coverage cho rules, auth và trạng thái publish. Có thể đặt baseline coverage sau khi test suite ổn định.

## 8. CI/CD & quality gates

1. Pull request → format/lint/types, unit, integration, contract, migration check.
2. Nếu sửa RAG/ingestion/schema → chạy offline eval/regression, hiển thị chênh lệch trước/sau.
3. Dependency security scan/secret scan; các findings critical phải xử lý hoặc được Product Owner chấp nhận với lý do.
4. Deploy staging → smoke test public chat và admin review flow.
5. Trước production: backup/restore verified, rollback path, quota/budget, release checklist signed.
6. Protected production secrets; không ghi API keys trong repo, logs hoặc docs.

## 9. Agent-driven implementation workflow

**Mỗi task giao cho Codex phải có:** `Goal`, `Related docs / FR IDs`, `Exact scope`, `Non-goals`, `Files/modules`, `Acceptance tests`, `Allowed dependencies`, `Review questions`.

**Required workflow:**

1. Đọc `AGENTS.md` và chỉ các tài liệu liên quan trực tiếp đến task.
2. Xác nhận assumptions/conflicts; nêu phương án thay đổi nếu ADR chưa chốt.
3. Thực hiện một vertical slice nhỏ và cập nhật tests/docs liên quan.
4. Chạy linter/types/test/eval tương ứng; báo lệnh và kết quả thực tế, không tuyên bố pass nếu chưa chạy.
5. Tạo implementation summary: changed files, decisions, limitations, follow-up.
6. **Stop để hỏi** nếu cần quyền AGU, dữ liệu không được phép dùng, production secrets, destructive migrations hoặc quyết định kiến trúc chưa phê duyệt.

### Definition of Done — mỗi task

- Chức năng thỏa acceptance criteria / FR ID.
- Lỗi, timeout, empty, authorization states có xử lý.
- Tests đã chạy hoặc nêu chính xác chưa thể chạy và lý do.
- Không có secrets/PII và dữ liệu công khai giả.
- API/schema/migration/doc được cập nhật nếu contract thay đổi.
- Logging/metrics phù hợp, không lộ raw dữ liệu nhạy cảm.

## 10. Code review checklist

- PR có scope hẹp và demo/tác vụ kiểm chứng được?
- Domain rules và truy xuất `published` được kiểm tra tại server?
- Có case dữ liệu cũ, thiếu năm, duplicate, race condition, provider outage?
- DB query được parameterize, index/migration hợp lý?
- Sources/citations thực sự có provenance và link hợp lệ?
- Có regression test khi thay model/chunking?
- Có đường rollback/cấu hình feature flag nếu rủi ro cao?

## 11. Security & privacy minimum

- Tuân thủ nguyên tắc OWASP web + OWASP LLM; threat model cho upload, crawl, admin, citation links và budget abuse.
- Không lưu conversation raw ở production mặc định nếu chưa có retention policy; log ẩn/mask identifiers.
- Role-based authorization backend; audit admin actions; CSRF/CORS/XSS protections.
- Provider credentials chỉ ở server; response không lộ prompt metadata/secrets.
- Khi xử lý dữ liệu cá nhân, rà soát nghĩa vụ pháp lý hiện hành với người phụ trách phù hợp trước go-live; tài liệu này không thay thế tư vấn pháp lý.

## 12. Change management

- **PRD change:** thêm/sửa requirement ID, acceptance criteria và roadmap.
- **Architecture change:** ADR mới hoặc sửa ADR trạng thái phù hợp, migration/rollback và impact analysis.
- **Model/data change:** dataset version + before/after eval + release notes.
- **Doc ownership:** Nếu code khác tài liệu, không lặng lẽ sửa code theo phỏng đoán; đề xuất để Product Owner duyệt nguồn chuẩn.

