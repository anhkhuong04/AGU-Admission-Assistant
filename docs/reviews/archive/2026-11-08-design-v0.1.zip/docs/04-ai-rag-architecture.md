# AGU Admission Assistant — AI & RAG Architecture

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Phương án đề xuất | Hybrid RAG + filtering + reranking + structured facts |
| Trạng thái | Architecture proposal; retrieval/model settings phải được benchmark |

## 1. Quality objective và trust boundary

Mục tiêu không phải tạo văn bản lưu loát, mà là **đưa kết luận tuyển sinh có evidence kiểm chứng được, đúng phạm vi và đúng thời điểm**. Mô hình AI không được là nguồn sự thật của học phí, hạn nộp, phương thức, điều kiện, chỉ tiêu.

**Trusted:** domain rules; schema; record đã kiểm duyệt; published source metadata; evidence IDs được server tạo.

**Untrusted:** câu hỏi người dùng, nội dung HTML/PDF, retrieved chunks, output của model, URL ngoài allowlist. Phân biệt untrusted với irrelevant: nguồn AGU vẫn có thể chứa lỗi OCR hoặc phiên bản cũ.

## 2. Why hybrid (not naive/graph/agentic by default)

| Hướng | Vai trò | Quyết định |
|---|---|---|
| Dense vector | Hiểu diễn đạt tự nhiên / thiếu từ khóa | Baseline + hybrid |
| Lexical/keyword | Mã ngành, năm, tổ hợp, tên riêng, văn bản | Baseline + hybrid |
| RRF fusion | Hợp nhất ranking khác thang điểm | Initial fusion; tune trên eval |
| Cross-encoder reranking | Chọn evidence thực sự phù hợp | Thử sau hybrid baseline |
| Parent–child context | Tìm đoạn nhỏ, trả mục cha đủ nghĩa | Áp dụng nếu chunk làm mất ngữ cảnh |
| GraphRAG | Truy vấn quan hệ nhiều-hop | Hoãn; structured SQL đủ cho MVP |
| Agentic multi-step | Lập kế hoạch gọi nhiều tool | Hoãn; tăng khó kiểm soát/chi phí |

**Lưu ý tiếng Việt:** PostgreSQL FTS thông thường không có phân đoạn từ tiếng Việt như các search engines chuyên dụng. Initial lexical nên kết hợp exact code match, title normalization, `pg_trgm`/trigram và `tsvector` đã cấu hình phù hợp; benchmark trên câu hỏi có dấu/không dấu. Không gọi PostgreSQL FTS là BM25 mặc định.

## 3. Runtime query pipeline

```mermaid
flowchart TB
  Q["User query"] --> U["Normalize + context + entity/year"]
  U --> R{"Router"}
  R -->|"Exact facts"| S["Verified SQL accessors"]
  R -->|"Narrative"| H["Hybrid retrieval + filters"]
  R -->|"Mixed"| M["Both paths"]
  H --> F["RRF + rerank + parent expansion"]
  F --> E["Evidence pack"]
  S --> E
  M --> E
  E --> V["Sufficiency/conflict checks"]
  V --> A["Grounded answer or abstain"]
  A --> C["Citation verification + response"]
```

### 3.1 Query understanding

- Normalize Unicode, whitespace; preserve nguyên văn mã ngành/tổ hợp/số và yêu cầu năm.
- Extract `intent`, `major_code/name`, `academic_year`, `admission_round`, `program_type`, `question_type`, `needs_clarification`.
- Resolve alias bằng bảng ngành đã duyệt; nếu tên ngành mơ hồ, hỏi lại; không tự áp mã ngành.
- Không suy ra `academic_year` từ ngày hiện tại khi câu hỏi phụ thuộc năm mà chưa rõ; UX có thể đưa year selector và nêu giả định được chọn.
- Conversation context chỉ hỗ trợ resolve referents; vẫn áp dụng bộ lọc nguồn tại mỗi lượt.

### 3.2 Query router

- `structured`: mã ngành, danh sách tổ hợp, số liệu/chỉ tiêu, mức học phí, deadline **đã được duyệt và typed**.
- `rag`: giải thích quy định, điều kiện, hướng dẫn, mô tả chương trình.
- `hybrid/mixed`: so sánh nhiều ngành và giải thích liên quan.
- `out_of_scope`: yêu cầu sau đại học, xét tuyển cá nhân, dữ liệu nội bộ; phản hồi ranh giới.
- Tất cả SQL là **parameterized query vào whitelisted repository functions**, không phát sinh arbitrary SQL từ LLM.

### 3.3 Retrieval and filtering

1. Resolve immutable snapshot của tập published documents tại query start.
2. Server-side filters: `program_type=undergraduate_full_time`, `approval=approved`, `publication=published`, `year`, `round` khi xác định, supersession/effective policy.
3. Dense top-k và lexical top-k riêng; exact-match boost chỉ với thực thể kiểm chứng; chuẩn hóa/ví dụ không dấu test riêng.
4. Hợp nhất bằng RRF: `score(d) = Σ 1/(k + rank_i(d))`, hằng số `k` khởi điểm 60, tune theo dataset.
5. Rerank 15–30 candidates → 3–6 evidence; tránh gửi nhiều đoạn trùng lặp từ cùng một trang.
6. Nếu chunk thiếu ngữ cảnh, expand theo parent section, không mở rộng sang văn bản khác năm/phiên bản.

Đây là **initial search configuration, không phải kết quả tối ưu**. Các tham số thay đổi phải chạy regression set.

### 3.4 Evidence pack

Mỗi bằng chứng cung cấp: `evidence_id`, `document_version_id`, `source_url`, `title`, `academic_year`, `round?`, `page?`, `section_path`, `text_excerpt`, `retrieval_scores`, `publication_state` và `content_checksum`. Evidence ID do server cấp, không phải LLM.

Trước generation: loại evidence không đúng thời gian, không đủ provenance, unpublished; deduplicate; xác định mâu thuẫn fact/giá trị/ngày. Trường hợp xung đột chưa giải quyết → `conflicting_sources`, không phán đoán “nguồn mới hơn luôn đúng”.

### 3.5 Generation & citation contract

- Prompt giới hạn model vào evidence pack và cho phép trả `insufficient_evidence`.
- Model xuất cấu trúc với `status`, `answer_claims[]`, `cited_evidence_ids[]`, `follow_up_questions[]`; backend validate bằng schema.
- Backend chỉ render citation IDs tồn tại trong evidence pack; kiểm tra các claim quan trọng có supporting evidence.
- Model không sinh raw URL citation, không có quyền upload/modify data từ chat public.
- Số liệu/tổ hợp/điều kiện có sẵn trong verified facts có thể render qua templates để giảm hallucination.
- Câu trả lời phân biệt *quy định hiện hành theo năm/đợt* với *tham khảo lịch sử*.

### 3.6 Output states và policy

| State | Khi nào | UX behavior |
|---|---|---|
| `answered` | Evidence đủ và không xung đột | Tóm tắt + nguồn + ngữ cảnh năm |
| `clarification_needed` | Thiếu năm/ngành/đối tượng | Hỏi tối đa 1–2 thông tin quan trọng |
| `insufficient_evidence` | Nguồn thiếu/chưa duyệt | Nói rõ chưa thể xác minh + official link |
| `conflicting_sources` | Không giải quyết được xung đột | Nêu tồn tại mâu thuẫn và không kết luận |
| `out_of_scope` | Ngoài đại học chính quy/ngoài quyền | Giải thích giới hạn, dẫn nguồn thích hợp |
| `service_unavailable` | Provider/infrastructure fail | Thông báo thử lại; không hiển thị nội dung suy đoán |

## 4. RAG injection defenses và privacy

- Xem nội dung tài liệu như **data only**; không cho retrieved text ghi đè system/developer instructions.
- Sanitize/escape HTML, cấm tool invocation từ text được truy xuất; allowlist source links.
- Không tiết lộ secrets, prompt nội bộ, raw logs hay thông tin của admin trong chat.
- Request size, user/IP quotas, output token ceiling, provider timeout, per-day model budget.
- Cách ly tài khoản admin khỏi public AI surface; không mount privileged functions cho public agent.
- Red-team prompts: “ignore previous instructions”, giả mạo quyết định, prompt injection ẩn trong PDF/HTML, khai thác system prompt, exfiltration links.

## 5. Model strategy / abstraction

**Chưa khóa vendor/model.** Thiết kế adapters `Embedder`, `Reranker`, `Generator`, `QueryClassifier`; config riêng model name, dimensions, version, timeout, usage. LLM chính chỉ gọi sau retrieval/sufficiency checks.

**Selection test:** Ít nhất 2 embedding models multilingual và 2 generation models trên tập câu hỏi AGU; đo Recall@k, MRR, faithfulness, citation correctness, latency, token cost. Reranker chỉ triển khai khi chất lượng cải thiện đủ để bù độ trễ. Khi đổi embedding dimensions/model, tạo namespace/index version mới, re-embed và switch atomically; không trộn vector khác model vào một index.

## 6. Evaluation-first delivery

### Gold dataset

- MVP tối thiểu 100–200 câu hỏi được gắn nhãn người kiểm duyệt: FAQ, câu hỏi giải thích, exact code, nhiều năm/đợt, typo/không dấu, câu hỏi không có đáp án, prompt injection.
- Mỗi case: `question`, `intent`, `year`, `gold_document_version_ids`, `gold_spans`, `expected_status`, `expected_facts`, `risk_level`, `reviewer`.
- Không dùng LLM làm nguồn ground truth duy nhất; có manual annotation/sample audit.

### Metrics / gates (đề xuất, điều chỉnh sau baseline)

| Stage | Metrics | Mục tiêu pilot đề xuất |
|---|---|---|
| Retrieval | Recall@5 | ≥90% trên answerable cases |
| Ranking | MRR@10, NDCG@k | So sánh baseline, không chốt ngưỡng trước dữ liệu |
| Answer | Claim factual accuracy | ≥95%; 0 lỗi critical chưa xử lý |
| Grounding | Citation support | ≥98% |
| Abstention | Correct abstention | ≥95% trên unanswerable set |
| Operations | P95 TTFT, token/query, failure rate | Theo NFR PRD; đo tải thực tế |

**Ablation:** (A) Dense only → (B) Dense + lexical/RRF → (C) + reranker → (D) + parent expansion/structured route; giữ nguyên dataset và source snapshot để so sánh. Báo cáo sai hỏng theo `ingestion`, `retrieval`, `reranking`, `generation`, `citation`, `temporal`.

## 7. Interfaces với ingestion/data

Ingestion xuất **immutable approved/published versions**, chunk metadata và `verified_facts` với provenance. Retrieval không được đọc trực tiếp raw OCR hoặc `pending_review` facts cho public. Publish/rollback làm invalidation cache; query log giữ version snapshot để tái lập. Giao thức chi tiết trong [`05-data-architecture.md`](05-data-architecture.md).

## 8. References

- pgvector hybrid search: https://github.com/pgvector/pgvector
- PostgreSQL full-text search: https://www.postgresql.org/docs/current/textsearch-intro.html
- OWASP LLM risk taxonomy: https://genai.owasp.org/llm-top-10/
- LlamaIndex ingestion concepts: https://developers.llamaindex.ai/python/framework-api-reference/ingestion/

