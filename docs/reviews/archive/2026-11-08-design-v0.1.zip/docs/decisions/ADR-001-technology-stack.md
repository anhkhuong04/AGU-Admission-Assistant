# ADR-001 — Technology Stack for AGU Admission Assistant

| Thuộc tính | Giá trị |
|---|---|
| ADR | 001 |
| Ngày | 2026-11-08 |
| Status | **Proposed — waiting for Product Owner approval** |
| Decision owner | Product Owner |
| Scope | MVP architecture/implementation |

## 1. Context

Sản phẩm website độc lập tư vấn tuyển sinh đại học chính quy AGU được phát triển bởi một developer + AI coding agent. Các drivers chính: dữ liệu PDF/HTML tiếng Việt, RAG có citation và phiên bản năm/đợt, admin content review, chi phí vận hành thấp, triển khai/rollback được và khả năng bàn giao về sau.

Không có tích hợp chính thức với hệ thống AGU. Số lượng người dùng, ngân sách và tài liệu đầu vào chưa được benchmark; quyết định stack là **proposed baseline**, không phải cam kết triển khai hạ tầng cụ thể.

## 2. Decision proposal

| Layer | Proposed choice | Reason |
|---|---|---|
| Public/admin frontend | **Next.js + React + TypeScript** | Responsive web, route-based app, SSR/SEO cho nội dung tĩnh |
| UI styling | CSS tokens + accessible component primitives; cân nhắc Fluent UI React v9 | Fluent 2-inspired consistency; không lock-in design package quá sớm |
| API backend | **Python + FastAPI** | Async APIs, type validation, AI/data Python ecosystem |
| AI orchestration | Service interfaces + **selective LlamaIndex** | Dùng ingestion/retrieval utilities nơi có ích; tránh framework lock-in |
| Document parsing | **Docling**, HTML parser, DOCX fallback | PDF layout, OCR/table support và pipeline thống nhất |
| Relational + vector | **PostgreSQL + pgvector** | One DB cho versions, users, facts, vectors |
| Lexical search | PostgreSQL `pg_trgm` + normalized exact/FTS | Mã ngành/keyword tiếng Việt; benchmark tokenizer |
| Retrieval | Metadata filter + dense/lexical + RRF; reranker optional | Recall tốt hơn baseline, đo được contribution |
| Object storage | S3-compatible private bucket hoặc tương đương | Immutable raw docs, export/restore |
| Ingestion execution | Separate Python worker; DB-backed jobs trước | Ít vận hành; nâng cấp queue khi tải tăng |
| Generator/embedder | **Provider adapters, models TBD by evaluation** | Đo tiếng Việt, latency và chi phí trước khi chốt |
| Tests | pytest, Playwright, CI, offline AI eval | Chất lượng, hồi quy, traceability |
| Deployment | Managed Postgres + frontend/API/worker services | Ít gánh nặng vận hành; provider lựa chọn sau |

**Version pinning:** Khi bootstrapping phải chọn và lock runtime/package versions ở lockfiles; ADR này không ấn định số phiên bản chưa xác minh tại thời điểm coding.

## 3. Key technical decisions

1. **Modular monolith, không microservices:** Một codebase backend với module boundary rõ; worker tách process vì parsing/embedding có thời gian chạy dài.
2. **Hybrid RAG + structured facts:** Văn bản pháp quy/mô tả qua retrieval; mã ngành, tổ hợp, số liệu qua verified SQL accessors khi đã có schema.
3. **Human-reviewed publish:** Parser/LLM có thể extract, không tự duyệt truth; dùng immutable document versions và release snapshot.
4. **Adapter boundaries:** `Parser`, `Embedder`, `Generator`, `Reranker`, `ObjectStorage`; thay vendor không đụng domain code.
5. **Evaluation before optimization:** Dense baseline → hybrid → rerank; compare trên cùng corpus/gold set trước khi khóa cấu hình.

## 4. Alternatives considered

| Alternative | Vì sao chưa chọn | Revisit khi |
|---|---|---|
| Java Spring Boot cho toàn backend | Rất phù hợp enterprise nhưng parsing/AI Python thường thuận lợi hơn cho solo developer | Product Owner ưu tiên Java portfolio/đội Java sẽ tiếp quản |
| Qdrant làm vector DB từ đầu | Thêm service và đồng bộ metadata khi corpus nhỏ | Search scale/latency/filters vượt ngưỡng Postgres |
| Elasticsearch/OpenSearch ngay từ MVP | Overhead cao cho domain nhỏ | Cần specialized Vietnamese lexical/relevance hoặc traffic lớn |
| GraphRAG / knowledge graph | Nặng extraction/maintenance; quan hệ ngành/năm đã có SQL | Nhiều truy vấn multi-hop không giải quyết tốt bằng SQL + RAG |
| Agentic RAG tự do | Tool/safety/cost complexity, khó tái lập eval | Có use cases multi-step thực sự được chứng minh |
| Fine-tune LLM theo văn bản tuyển sinh | Quy định thay đổi theo năm; fine-tune không thay quản trị nguồn | Có tập labeled lớn và tác vụ ổn định khác retrieval |
| Vector-only store | Mất exact constraints/relation/version control | Không khuyến nghị với nghiệp vụ tuyển sinh |

## 5. Consequences / trade-offs

### Positive

- Đơn giản hóa vận hành, dùng PostgreSQL cho source metadata, content versions, structured facts và embeddings.
- Hỗ trợ cả retrieval ngữ nghĩa lẫn tìm mã ngành, năm, số liệu chính xác.
- Dễ kiểm thử ingestion và grounded answer, có đường audit/rollback.
- Python thuận tiện để tạo PoC tài liệu thô trước UI.

### Costs / risks

- Python và TypeScript hai ecosystem: cần CI, type contract/OpenAPI và lockfiles.
- PostgreSQL lexical mặc định có giới hạn phân đoạn tiếng Việt; phải benchmark exact/trigram/FTS và normalized aliases.
- pgvector và các chỉ mục approximate có tuning; quy mô/tải chưa biết, chưa được coi là tối ưu đã chứng minh.
- Docling OCR/table extraction vẫn có sai sót; con người kiểm chứng dữ liệu quan trọng.
- Sử dụng LLM API tạo chi phí biến thiên; cần budget guardrails.

## 6. Validation plan before ADR Accepted

1. **Corpus PoC:** 15–30 trang/tài liệu AGU thật đại diện HTML, PDF text và scan/table; ghi lỗi parser.
2. **Search benchmark:** ≥100 câu hỏi gold gồm tiếng Việt không dấu, tên ngành, mã ngành, năm/đợt; compare dense/hybrid/rerank.
3. **DB feasibility:** Migration, publication snapshots, rollback, query filtered by year; đo latency và index storage.
4. **Cost benchmark:** Token/query và chi phí ingest một đợt tài liệu; dự toán theo tải pilot.
5. **Frontend proof:** Demo mobile chat streaming + citations + admin document review.

**Acceptance decision:** Product Owner xem bảng so sánh chất lượng/chi phí/độ phức tạp; nếu đạt, chuyển `Status` thành `Accepted` và ghi ngày/lý do. Nếu không đạt, tạo ADR thay thế; không sửa lặng lẽ quyết định đã Accepted.

## 7. Decisions deliberately deferred

- Exact LLM, embedding, reranker; host/provider và datacenter; paid vs self-host.
- Identity provider/admin MFA, S3 provider, monitoring vendor.
- Celery/Redis: chỉ dùng khi DB jobs không đáp ứng reliability/throughput.
- HNSW/IVFFlat: chọn sau đo corpus/latency/recall, không bắt buộc ngay PoC.
- Brand/logo/domain chính thức: cần authorization riêng nếu dùng thương hiệu AGU.

## 8. References / links

- FastAPI: https://fastapi.tiangolo.com/
- PostgreSQL: https://www.postgresql.org/docs/
- pgvector: https://github.com/pgvector/pgvector
- Docling: https://github.com/docling-project/docling
- LlamaIndex: https://developers.llamaindex.ai/python/
- Next.js: https://nextjs.org/docs
- OWASP LLM risks: https://genai.owasp.org/llm-top-10/

