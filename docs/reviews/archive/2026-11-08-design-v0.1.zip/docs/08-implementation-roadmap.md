# AGU Admission Assistant — Implementation Roadmap

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Nguồn lực | 1 developer + AI coding agent |
| Kế hoạch | 12–16 tuần **ước tính**, chưa cam kết lịch |
| Release target | Public pilot độc lập, có nguồn kiểm chứng; không phải hệ thống chính thức AGU |

## 1. Delivery strategy

**Ưu tiên:** Data quality → Retrieval quality → End-to-end MVP → Production hardening → UX/business P1.

**Phương pháp:** Vertical slices, task nhỏ có FR/AC IDs; demo ở cuối milestone; thay đổi kiến trúc cần ADR. Không làm toàn bộ frontend trước khi ingestion/RAG có bằng chứng chất lượng.

**Giả định tiến độ:** một developer có thể dành thời gian ổn định mỗi tuần, sử dụng managed infrastructure và không có yêu cầu tích hợp nội bộ AGU. Nếu thiếu dữ liệu chất lượng hoặc phải làm OCR nhiều, tăng thời gian PoC trước khi tiếp tục.

## 2. Phase plan / exit gates

| Phase | Ước lượng | Deliverable | Exit gate bắt buộc |
|---|---|---|---|
| 0 — Design review | Tuần 1–2 | 9 docs duyệt, ADR, source inventory, eval protocol | Không còn P0 architectural blockers |
| 1 — Data foundation PoC | Tuần 3–5 | Parse 15–30 docs; IR, review queue, DB, raw storage | Bảng/số liệu critical được QA; retry/idempotent |
| 2 — RAG evaluation | Tuần 6–8 | Dense baseline, hybrid + filters, citation, abstention | Báo cáo 100–200 câu hỏi, failure taxonomy |
| 3 — Vertical MVP | Tuần 9–11 | Chat public + Admin review/publish + auth + tests | E2E user/admin flows, không có draft leakage |
| 4 — Pilot hardening | Tuần 12–16 | Monitoring, quotas, accessibility, load/security tests, deployment | Release checklist + rollback + pilot report |

**P1** (Major Explorer, comparison, personalized guidance) bắt đầu **sau** khi Phase 4 đạt exit gate hoặc nếu năng lực/corpus cho phép mà không trì hoãn chất lượng P0.

## 3. Dependency graph

```mermaid
flowchart TB
  A["Approve PRD + ADR"] --> B["Source inventory + gold eval set"]
  B --> C["Parser + canonical IR + QA"]
  C --> D["Versioned DB + publish workflow"]
  D --> E["Hybrid retrieval + citation"]
  E --> F["Public chat + Admin UI"]
  F --> G["Security + load + pilot"]
```

Tập eval bắt đầu **trước** khi chọn embedding/LLM. Review/publish là dependency của public retrieval. Không cho agent bỏ qua gate vì demo chat đã trả lời trôi chảy.

## 4. Work packages — implementation backlog

| ID | Priority | Deliverable | Dependencies | Acceptance / tests |
|---|---|---|---|---|
| WP-01 | P0 | Repo scaffold, local dev, env templates | ADR approved | `make dev/test` hoặc scripts tương đương chạy được |
| WP-02 | P0 | Source manifest + crawler allowlist/upload | WP-01 | Không SSRF, dedup checksum, provenance |
| WP-03 | P0 | Parser HTML/PDF/DOCX + canonical IR | WP-02 | Golden documents parse QA |
| WP-04 | P0 | Document version schema, migrations, object store | WP-01 | Migration + idempotency + backup smoke |
| WP-05 | P0 | QA/review/approval/publication workflow | WP-03/04 | Draft isolation, audit, atomic release, rollback |
| WP-06 | P0 | Gold question/evidence dataset & eval runner | WP-02 | Có versioned labeled cases, metrics reproducible |
| WP-07 | P0 | Dense retrieval baseline | WP-03/04/06 | Report Recall@k, failure cases |
| WP-08 | P0 | Lexical + hybrid RRF + metadata filters | WP-07 | A/B vs baseline; exact year/code cases |
| WP-09 | P0 | Reranking + evidence validation + citation | WP-08 | Citation support and temporal tests |
| WP-10 | P0 | Public chat API, statuses, streaming | WP-09 | API contract + timeout/abstention tests |
| WP-11 | P0 | Admin auth + sources/review UI | WP-05 | RBAC + approve/publish E2E |
| WP-12 | P0 | Public web Home/Assistant/Help/About | WP-10 | Mobile + accessibility + links |
| WP-13 | P0 | Observability, quotas, alerts, CI/CD | WP-01/10 | Logs safe; budgets and smoke tests |
| WP-14 | P0 | Security, load, restore/rollback exercises | WP-10..13 | Critical defects closed, release checklist |
| WP-15 | P1 | Structured facts, typed accessors | WP-05 | Table review + fact/source provenance |
| WP-16 | P1 | Major Explorer + comparison | WP-15 | Source-backed records, missing states |
| WP-17 | P1 | Guided admissions + feedback analytics | WP-10/12 | Tested flows, no official impersonation |

## 5. Sprint/task handoff template for coding agents

```md
## Goal
<Một mục tiêu kiểm chứng được>

## Source of truth
- docs/02-prd.md: FR-xx, AC-yy
- docs/03-system-architecture.md: module / API contract
- docs/05-data-architecture.md: schema / invariants

## Scope
- Implement ...

## Non-goals
- Do not change ...

## Acceptance tests
1. ...
2. ...

## Deliverables
- Code, migration/test/docs update, command results, open questions.
```

Chia work package thành tasks có thể hoàn thành/review trong 0,5–2 ngày khi bắt đầu coding. Không yêu cầu Codex “implement the entire app” trong một turn.

## 6. Milestone reviews — Product Owner sign-offs

| Gate | Câu hỏi cần review | Hành động nếu không đạt |
|---|---|---|
| G0 | Scope, ADR, nguồn, tiêu chí eval đã rõ? | Chốt docs trước code |
| G1 | Có parse đúng bảng, ngày, mã ngành? | Chỉnh parser/QA, giảm scope tài liệu |
| G2 | Hybrid có cải thiện baseline, có tránh sai năm? | Điều chỉnh filters/chunking/index, chưa làm P1 |
| G3 | Public không truy xuất draft, citation đúng, admin rollback được? | Block pilot, sửa critical |
| G4 | Bảo mật, tải, quan sát, chi phí, disclaimer đáp ứng? | Giới hạn beta/private access cho đến khi ổn |

## 7. Risk register / contingency

| Risk | Trigger | Response |
|---|---|---|
| Parser OCR không đủ chính xác | Sai số/ngày/tổ hợp trong gold set | Human review, typed extraction, bổ sung parser khác cho loại PDF đó |
| Tài liệu không đủ hoặc mâu thuẫn | Nhiều câu không có evidence | Thu hẹp chủ đề/năm, abstain, không kéo nguồn thứ cấp thiếu thẩm định |
| Model quá đắt/chậm | P95 và cost vượt budget | Model routing, caching verified facts, tối ưu candidate count |
| Một developer bị quá tải | Milestone liên tiếp trễ | Giữ FR-01..12, hoãn P1/P2, rút gọn admin UI |
| Điều kiện sử dụng dữ liệu/thương hiệu chưa rõ | Trước public release | Giữ staging/private pilot, review nguồn/disclaimer |
| Provider outage | Lỗi 5xx/timeout kéo dài | Graceful fallback, alert, retry, không tự sinh đáp án |

## 8. Definition of Ready / Done

### Ready (một task)

- FR ID, scope và non-goals rõ; docs không mâu thuẫn.
- Inputs/datasets/fixtures có thể truy cập; quyết định công nghệ cần thiết đã được duyệt.
- Acceptance tests, success/failure states, review owner được xác định.

### Done (một task)

- Thỏa AC; có tests tương ứng; lint/types/CI không lỗi liên quan.
- Có evidence từ lệnh test đã chạy; cập nhật schema/docs nếu có thay đổi.
- Có kiểm tra bảo mật, privacy và rollback khi liên quan.
- Chưa hoàn thành thì ghi rõ blocker; không gắn trạng thái `Done` vì AI tạo code xong.

## 9. Pilot launch checklist

- [ ] Chốt branding/disclaimer dự án độc lập, link đến AGU official.
- [ ] Xác nhận quyền/điều kiện sử dụng dữ liệu cần thiết.
- [ ] Tập dữ liệu published được duyệt; version và citations kiểm chứng.
- [ ] Critical eval cases pass; báo cáo chất lượng/giới hạn minh bạch.
- [ ] Rate limit, secret management, admin RBAC, upload & SSRF tests.
- [ ] Backup + restore rehearsal; published rollback rehearsal.
- [ ] Uptime/logging/budget alerts; xử lý lỗi provider offline.
- [ ] Mobile/accessibility/usability pilot.
- [ ] Product Owner ký duyệt phát hành và ghi known limitations.

## 10. Immediate next actions sau review

1. Phê duyệt/ghi chú vào 9 tài liệu; chốt ADR-001 và scope nguồn 2026.
2. Khởi tạo `AGENTS.md` ngắn trỏ đến docs được duyệt; scaffold repo.
3. Tạo `tests/fixtures/` + 15–30 tài liệu thực có provenance và tập câu hỏi gold ban đầu.
4. Chạy WP-02..06; review parsing trước khi triển khai chatbot.

