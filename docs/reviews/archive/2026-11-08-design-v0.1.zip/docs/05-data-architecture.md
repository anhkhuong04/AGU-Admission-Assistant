# AGU Admission Assistant — Data Architecture & Ingestion Specification

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Module | Knowledge ingestion, PostgreSQL, raw storage, structured admission facts |
| Trạng thái | Proposed data contracts; cần thử nghiệm với PDF/HTML AGU thực tế |

## 1. Data principles

1. **Immutable raw:** Giữ nguyên tài liệu gốc + provenance + checksum; xử lý lại không mất nguồn.
2. **Separate content and validity:** Văn bản được parse không đồng nghĩa dữ liệu đúng; index xong không đồng nghĩa được publish.
3. **Versioned published knowledge:** Public truy xuất một snapshot đã duyệt; rollback an toàn.
4. **Dual storage:** Văn bản dài cho RAG; facts chính xác cho SQL; cả hai dẫn về cùng nguồn.
5. **No ungrounded facts:** Mỗi số liệu nghiệp vụ phải có document version + span/table cell/nguồn được kiểm tra.
6. **Time-aware:** `published_at`, `effective_from`, `effective_until`, `academic_year`, `admission_round` là các trường **khác nhau**; null ≠ mặc định hiện hành.
7. **Repeatable:** Ingestion versioned, idempotent, có log QA/review và reprocessing.

## 2. Source inventory và allowlist

**Nguồn khởi đầu được xem xét (không mặc định auto-publish):**

- Trang tuyển sinh: https://tuyensinh.agu.edu.vn/
- Các trang tin tức/thông báo/đính kèm tuyển sinh **đại học chính quy**.
- Trang ngành đào tạo và PDF/DOCX công khai liên quan.

**Source manifest:** `source_id`, `canonical_url`, `source_type`, `discovered_at`, `retrieved_at`, `http_etag?`, `last_modified?`, `sha256`, `content_type`, `publisher`, `license_review_status`, `crawl_status`.

**Boundary:** Chỉ theo danh sách domain/path cho phép; tôn trọng robots/điều kiện truy cập, rate limit, redirect allowlist, giới hạn content length và timeout. Từ chối URL private-IP/localhost sau DNS resolution và redirects; không dùng nguồn ngoài để chèn dữ liệu tuyển sinh.

## 3. Ingestion pipeline — state machine

```mermaid
stateDiagram-v2
  [*] --> discovered
  discovered --> downloaded
  downloaded --> parsed
  parsed --> normalized
  normalized --> validated
  validated --> pending_review
  pending_review --> approved
  pending_review --> rejected
  approved --> indexed
  indexed --> published
  published --> superseded
  published --> unpublished
  parsed --> failed
  normalized --> failed
  validated --> failed
  failed --> downloaded: retry / reprocess
```

**Lưu ý nghiệp vụ:** `superseded` chỉ khi reviewer xác nhận tài liệu thay thế; không xóa bản cũ. `unpublished` chặn truy xuất public nhưng vẫn giữ nguồn/audit. Quá trình index có thể hoàn thành **trước** khi publish mà không làm lộ dữ liệu.

### Stage contracts

| Stage | Input | Output | Quality gate |
|---|---|---|---|
| Discover | URL / upload | Source record | Scope, allowlist, dedup URL |
| Download | Source record | Immutable raw bytes | MIME/magic bytes, size, checksum, status |
| Parse | PDF/DOCX/HTML | Document blocks + tables + page refs | Parse success, OCR confidence/coverage |
| Normalize | Raw blocks | Canonical document tree | Heading hierarchy, Unicode, preserve tables |
| Extract metadata | Canonical tree | Year, round, decision code, dates | Không infer missing critical fields |
| Validate | Canonical tree + metadata | QA report + warnings | Chặn ambiguous values, table corruption |
| Review | Preview + QA | Approval/rejection audit | Human confirmation critical facts |
| Chunk | Approved doc | Section-aware nodes | Không mất table/page/provenance |
| Embed/index | Chunks | Vector + lexical index | Dimensions/model version/index counts |
| Publish | Index-ready version | Active release state | Atomic switch + cache invalidation |

## 4. Parser strategy by source type

| Input | Parser | Bảo toàn | Kiểm định đặc biệt |
|---|---|---|---|
| HTML | Trafilatura/BeautifulSoup + rules | Heading, article body, tables, links | Loại menu/sidebar/footer/lặp |
| Digital PDF | Docling standard layout | Paragraph, section, pages, table cells | So sánh text layer vs rendered |
| Scan PDF | Docling OCR (engine benchmark tiếng Việt) | Page image positions, cell relationships | Tên ngành, số liệu, ngày, dấu tiếng Việt |
| DOCX | Docling hoặc python-docx fallback | Headings, tables, bullet lists | Merged cells và chú thích cuối bảng |
| XLSX (nếu có sau MVP) | openpyxl/csv parser | Typed cells, sheet, formulas/cached values | Công thức vs values, năm/sheet |

**Không xuất PDF thành một chuỗi text duy nhất** nếu có bảng hoặc cấu trúc điều/khoản. Khi OCR/table confidence thấp, tạo `review_task` kèm preview trang. OCR confidence không đủ để xác nhận nội dung pháp lý/nghiệp vụ.

## 5. Canonical Intermediate Representation (IR)

Parser xuất một mô hình trung gian **trước chunking**. Ví dụ:

```json
{
  "document_version_id": "uuid",
  "parser_version": "docling-config-v1",
  "title": "Tên văn bản nguồn",
  "language": "vi",
  "academic_year": 2026,
  "program_type": "undergraduate_full_time",
  "published_at": null,
  "effective_from": null,
  "sections": [{
    "section_path": ["II", "2", "a"],
    "heading": "Điều kiện xét tuyển",
    "page_start": 3,
    "blocks": [{"type": "paragraph", "text": "..."}]
  }],
  "tables": [{
    "table_id": "t1",
    "page": 4,
    "columns": ["Mã ngành", "Tên ngành", "Tổ hợp"],
    "rows": [["7480201", "Công nghệ thông tin", "A00, A01"]],
    "review_status": "pending"
  }]
}
```

**Dữ liệu trong ví dụ là minh họa, không xác nhận tổ hợp hoặc quy định AGU.** Bắt buộc giữ `document_version_id`, `source_url`, page/section, parser config, nguyên bản và các cảnh báo.

## 6. Chunking policy

- Chunk theo heading/điều/khoản/list, không chia cứng tài liệu ở ranh giới ngữ nghĩa.
- Baseline thử 300–600 tokens, overlap 50–100 **chỉ khi chia đoạn dài**; không áp overlap vào bảng nguyên khối.
- Gắn breadcrumb tiêu đề vào embedding input; giữ `content` nguyên văn làm evidence.
- Các bảng có mã/tổ hợp/chỉ tiêu chuyển **riêng** sang fact extraction; vẫn giữ table representation liên kết nguồn.
- Parent–child: search trên child chunk nhưng có thể mở rộng parent section cùng document version.
- Dedup theo canonical content hash và ID; không trộn documents khác năm hoặc đợt.
- Chunks giữ `chunk_type`, `section_path`, `page_start/end`, `position`, `language`, `academic_year`, `round`, `model_version`.

## 7. Logical relational schema

```mermaid
erDiagram
  SOURCES ||--o{ DOCUMENTS : contains
  DOCUMENTS ||--o{ DOCUMENT_VERSIONS : versions
  DOCUMENT_VERSIONS ||--o{ DOCUMENT_BLOCKS : parsed_as
  DOCUMENT_VERSIONS ||--o{ DOCUMENT_CHUNKS : indexed_as
  DOCUMENT_VERSIONS ||--o{ ADMISSION_FACTS : supports
  DOCUMENT_VERSIONS ||--o{ REVIEW_TASKS : reviewed_by
  DOCUMENT_VERSIONS ||--o{ PUBLICATION_EVENTS : audited_by
  INGESTION_JOBS }o--|| DOCUMENT_VERSIONS : processes
```

### Table contracts

| Table | Khóa/chỉ mục quan trọng | Trách nhiệm |
|---|---|---|
| `sources` | `id`, unique canonical URL (theo source type) | Provenance, allowlist, crawl metadata |
| `documents` | `id`, `source_id`, logical document key | Danh tính tài liệu qua các lần cập nhật |
| `document_versions` | `id`, `document_id`, SHA-256, `parser_version`, lifecycle | Bản raw/parsed bất biến, quan hệ supersession |
| `document_blocks` | `version_id`, page, order, block type, JSONB | Canonical IR để review/chunk lại |
| `document_chunks` | `version_id`, chunk index, content, embedding, lexical | Retrieval evidence có provenance |
| `admission_facts` | `source_version_id`, type, key, academic_year | Facts verified/typed + evidence refs |
| `publication_events` | `version_id`, actor, action, timestamp | Audit publish/unpublish/rollback |
| `ingestion_jobs` | id, version, attempt, stage, idempotency key | Retry, dead-letter, telemetry |
| `review_tasks` | version/fact, severity, status, reviewer | Human QA decisions |
| `evaluation_cases/runs` | dataset version, model/index version | AI regression and quality audit |

### Typed fact model (P1)

`admission_facts` không nên là JSONB tùy ý duy nhất. Giai đoạn đầu có typed record với `fact_type`, `value_json`, `unit`, `scope`, `academic_year`, `admission_round`, `major_id?`, `source_version_id`, `source_location`, `verification_status`. Sau khi xác định use cases ổn định, tách `majors`, `admission_methods`, `major_combinations`, `quotas`, `tuition_fees`, `deadlines` bằng foreign keys, unique constraints và kiểu ngày/tiền/tổ hợp cụ thể.

Đối với tiền/hạn chót, không lưu mỗi `string`: cần đơn vị tiền, kỳ/năm áp dụng, múi giờ và mốc thời gian chính thức; null cho unknown, không dùng 0 để đại diện missing.

## 8. Schema patterns / indexing

Minh họa (không phải migration hoàn chỉnh):

```sql
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Embedding dimension phải khớp model đã chọn; ví dụ 1024 chỉ để minh họa.
CREATE TABLE document_chunks (
  id uuid PRIMARY KEY,
  document_version_id uuid NOT NULL,
  chunk_index integer NOT NULL,
  content text NOT NULL,
  embedding vector(1024),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  search_tsv tsvector GENERATED ALWAYS AS
    (to_tsvector('simple', coalesce(content, ''))) STORED,
  UNIQUE (document_version_id, chunk_index)
);
CREATE INDEX idx_chunks_lexical ON document_chunks USING gin(search_tsv);
CREATE INDEX idx_chunks_trgm ON document_chunks USING gin(content gin_trgm_ops);
-- Vector index (HNSW/IVFFlat) được tạo sau benchmark kích cỡ/tải thực tế.
```

Production migration bổ sung FKs, checks, scope/year/indexing fields dạng cột, policy filter, partitioning nếu cần. Với tiếng Việt, `simple` tokenizer không tương đương word segmentation; exact/trigram/search normalized fields cần benchmark, không giả định PostgreSQL mặc định có BM25.

## 9. Publication/version consistency

**Proposed release design:** `knowledge_releases(id, created_by, status, created_at)` và `release_documents(release_id, document_version_id)` lưu tập phiên bản được phê duyệt. `active_release_id` là con trỏ hệ thống. Ingestion xây index/version trước; admin publish release bằng một transaction. Query lấy `active_release_id` **một lần** tại đầu request; mọi retrieval và fact query lọc theo release đó để tránh câu trả lời trộn hai phiên bản. Rollback chuyển con trỏ sang release trước đã kiểm chứng. Xóa/thu hồi khẩn cấp phải có override chặn public ngay cả khi release cũ vẫn tồn tại.

**Supersession policy:** Có `supersedes_version_id`, `reason`, `confirmed_by`, `confirmed_at`. Thông báo mới không nhất thiết thay toàn bộ thông báo cũ; có thể thay **một fact hoặc một đợt**, do đó phải quản lý scope của thay đổi hoặc đánh dấu conflict để review. Không xóa hard-delete nguồn trong thời gian audit cần thiết.

## 10. QA gates / human review checklist

| Rule | Failure action |
|---|---|
| Scope không phải đại học chính quy | Quarantine/out of scope |
| Không xác định được năm tuyển sinh nhưng tài liệu chứa rules phụ thuộc năm | Review bắt buộc |
| PDF OCR rỗng/gãy, số trang bất thường | Fail parse/review |
| Bảng có merged cells, mất header, số/đơn vị mơ hồ | Block verified-fact publish |
| Cùng key + year + round có facts trái nhau | Conflict queue, không tự chọn |
| Một document version được re-ingest không đổi checksum/config | Skip compute, no duplicate |
| Thay embedding model/config | Tạo index namespace mới, đo eval rồi switch |
| Citation không map tới URL/position bản gốc | Block hoặc đánh `uncitable` |

**Review UI cần có:** raw original/preview, extracted blocks/table side-by-side, highlight QA issues, metadata editable, version comparison, approve/reject với lý do và actor.

## 11. Error handling, retention, backup

- Retry transient network/OCR/provider failures với exponential backoff + max attempts; permanent validation errors không retry vô hạn.
- Dead-letter/quarantine failures; job logs có stage/trace, không mất raw nguyên bản.
- Giới hạn file, pages, parser CPU/memory, embedding batch size, timeout; tất cả cấu hình theo môi trường.
- Backup PostgreSQL + object storage, thử restore định kỳ; bảo vệ secrets; tối thiểu hóa PII.
- Tài liệu public của AGU không đồng nghĩa được phép tái phân phối vô hạn: review điều kiện sử dụng trước pilot; có phương án giữ link/provenance thay vì công khai bản sao file gốc.
- Retention raw/versions/audit/conversation phải được phê duyệt; không tự đặt thời hạn mang tính pháp lý khi chưa có chính sách.

## 12. Testing & evidence of completion

1. **Golden parse set:** ít nhất 15–30 tài liệu đa dạng; review thủ công đoạn điều/khoản, bảng, ngày, mã ngành.
2. **Table correctness:** Test so từng cell quan trọng với ảnh/PDF gốc; không chỉ đo text similarity.
3. **Idempotency:** Cùng file/config nạp hai lần không tạo duplicate chunks/facts.
4. **Release isolation:** Draft/rejected không xuất hiện public; rollback giữ câu trả lời nhất quán.
5. **Temporal correctness:** Năm/đợt/hạn và ngày đăng bài phân biệt được.
6. **Traceability:** Mỗi fact và chunk public truy về raw version + section/page/URL.
7. **Re-embedding:** Thay model trên index mới, benchmark rồi switch không downtime dữ liệu.

## 13. Open decisions

- Chọn parser/OCR mode cho tài liệu scan tiếng Việt sau PoC.
- Chọn chiến lược lexical cho tiếng Việt sau so sánh exact/trigram/FTS.
- Chốt embedding model/dimensions, index ANN/exact và kích cỡ corpus.
- Chốt object storage và budget retention; nguồn nào được phép lưu/tái phân phối.
- Chốt entity/fact normalization, nguồn dữ liệu ưu tiên của từng nhóm trường.

## 14. References

- Docling OCR and table concepts: https://github.com/docling-project/docling
- pgvector indexing/hybrid: https://github.com/pgvector/pgvector
- LlamaIndex ingestion, dedup/cache: https://developers.llamaindex.ai/python/framework-api-reference/ingestion/
- AGU admission portal: https://tuyensinh.agu.edu.vn/

