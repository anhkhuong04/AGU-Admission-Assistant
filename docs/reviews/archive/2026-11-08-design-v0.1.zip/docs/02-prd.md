# AGU Admission Assistant — Product Requirements Document (PRD)

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Product Owner | Chủ dự án |
| Trạng thái | Business requirements proposed, chờ duyệt |
| Phạm vi | Website độc lập tư vấn tuyển sinh **đại học chính quy AGU** |

## 1. Mục tiêu và phạm vi phát hành

**MVP goal:** Người dùng đặt câu hỏi tuyển sinh, nhận câu trả lời tiếng Việt có dẫn chứng đúng tài liệu/năm hoặc lời giải thích minh bạch khi không đủ cơ sở; quản trị viên có thể duyệt, phát hành và thu hồi dữ liệu mà không sửa source code.

**Đo thành công:** Dùng bộ câu hỏi chuẩn và usability tests; mục tiêu pilot trong `01-product-overview.md`. Chưa đo lượng truy cập hay tỷ lệ chuyển đổi trước khi có người dùng thật.

**Không làm ở MVP:** chatbot đa lĩnh vực, hồ sơ cá nhân, nộp đơn, tự động xác nhận trúng tuyển, voice/avatar, AI chấm điểm phù hợp ngành.

## 2. Personas / use contexts

| Persona | Nhu cầu | Rủi ro UX |
|---|---|---|
| P-A: thí sinh lớp 12 | Phương thức, ngành, tổ hợp, mốc thời gian | Nhầm giữa các năm/đợt |
| P-B: phụ huynh | Học phí, quy trình, kênh xác minh | Tin lời chatbot như công bố chính thức |
| P-C: thí sinh đã tốt nghiệp | Hồ sơ, đối tượng, điều kiện cụ thể | Thiếu điều kiện riêng trong tài liệu |
| P-D: quản trị nội dung | Cập nhật quyết định/thông báo và kiểm tra chất lượng | Phê duyệt nhầm tài liệu lỗi |

## 3. User journeys trọng tâm

### J1 — Hỏi đáp có dẫn nguồn (MVP)

1. Người dùng mở `/assistant` không cần đăng nhập.
2. Chọn năm hoặc để hệ thống yêu cầu làm rõ nếu câu hỏi phụ thuộc năm và không có ngữ cảnh.
3. Nhập câu hỏi; giao diện hiển thị tiến trình.
4. Hệ thống truy xuất nguồn đã duyệt, kiểm tra xung đột và tạo câu trả lời.
5. Hiển thị nguồn, tên văn bản, năm và liên kết. Người dùng có thể đánh giá câu trả lời.

**Alternate flows:** Chưa có tài liệu → nêu chưa đủ dữ liệu + nguồn chính thức; tài liệu xung đột → không khẳng định giá trị duy nhất; dịch vụ AI lỗi → thông báo, không hiển thị nội dung suy đoán.

### J2 — Quản trị và phát hành tài liệu (MVP)

1. Admin đăng nhập; thêm URL hoặc upload PDF/DOCX/HTML hợp lệ.
2. Ingestion chạy background, lưu bản gốc, parsing và báo cáo lỗi.
3. Admin xem preview, metadata, bảng/chunk và các cảnh báo OCR/xung đột.
4. Admin duyệt hoặc trả về sửa/loại bỏ.
5. Hệ thống index *version* đã duyệt; chuyển con trỏ published atomically sau khi index thành công.
6. Admin có thể unpublish/rollback; truy vấn mới ngừng dùng bản thu hồi.

### J3 — Khám phá/so sánh ngành (post-MVP)

1. Chọn năm, duyệt danh sách ngành (filter/search).
2. Chọn 2–3 ngành để so sánh chương trình, tổ hợp, chỉ tiêu/học phí **nếu đã được xác minh**.
3. Xem nguồn cho từng trường dữ liệu, chỗ thiếu thể hiện `Chưa có dữ liệu xác thực`.

## 4. Feature backlog và priority

`P0` bắt buộc để public pilot; `P1` mở rộng sau kiểm định P0; `P2` cân nhắc theo dữ liệu sử dụng.

| ID | Priority | Functional requirement | Acceptance criteria tóm tắt |
|---|---|---|---|
| FR-01 | P0 | Chat tiếng Việt, multi-turn trong phiên | Câu hỏi theo sau dùng đúng ngữ cảnh; reset tạo phiên mới |
| FR-02 | P0 | Tra cứu chỉ từ nguồn tuyển sinh chính quy đã publish | Không dùng bản draft/unpublished hoặc ngoài scope |
| FR-03 | P0 | Source citation mỗi kết luận quan trọng | Citation mở đúng tài liệu; trang/section khi có |
| FR-04 | P0 | Nhận biết năm/đợt/hiệu lực | Không coi dữ liệu năm trước là dữ liệu năm mới |
| FR-05 | P0 | Abstention và clarification | Không tự bịa hạn chót/học phí/điều kiện |
| FR-06 | P0 | Trang giới thiệu/FAQ/các liên kết chính thức | Hiện rõ độc lập, không đại diện AGU |
| FR-07 | P0 | Admin authentication + role guard | Public không truy cập admin API |
| FR-08 | P0 | Upload/URL ingestion với job status | Có progress, parse report, lỗi phục hồi được |
| FR-09 | P0 | Review/approve/publish/unpublish/rollback | Chỉ bản đã duyệt mới được public truy xuất |
| FR-10 | P0 | Test set, run eval, báo cáo | So sánh retrieval/citation/answer theo release |
| FR-11 | P0 | Observability + cost/rate limits | Có request ID, latency, lỗi, usage/token, alarm |
| FR-12 | P0 | Input safety và privacy | PII redaction trong logs, upload limits, chống abuse |
| FR-13 | P1 | Major Explorer | Trang lọc ngành theo năm từ dữ liệu đã duyệt |
| FR-14 | P1 | Major Comparison | So sánh 2–3 ngành, nguồn từng thuộc tính |
| FR-15 | P1 | Guided admission checklist | Thể hiện bước, điều kiện, nguồn, mốc thời gian |
| FR-16 | P1 | Structured fact extraction & lookup | Có review trước khi trả lời từ structured DB |
| FR-17 | P1 | Feedback hữu ích/không hữu ích | Không yêu cầu danh tính; cho phép báo lỗi nguồn |
| FR-18 | P1 | Quality analytics | Nhóm chủ đề, lỗi, tỷ lệ abstain, retrieval failures |
| FR-19 | P1 | Document change discovery | Chỉ đưa thay đổi qua review; không auto publish |
| FR-20 | P1 | Human escalation | Trỏ tới kênh AGU công khai, không giả lập chuyển nội bộ |
| FR-21 | P2 | Lịch sử hội thoại tùy chọn | Opt-in, xóa được, có chính sách lưu rõ ràng |
| FR-22 | P2 | Tư vấn định hướng ngành có giải thích | Không khẳng định đầu ra nghề nghiệp/trúng tuyển |

## 5. Business rules (BR)

| ID | Quy tắc bắt buộc |
|---|---|
| BR-01 | Hệ đào tạo mặc định và duy nhất của MVP: `undergraduate_full_time` |
| BR-02 | Các thông tin phụ thuộc thời gian phải gắn `academic_year`; đợt chỉ được dùng khi tài liệu có khai báo |
| BR-03 | Trạng thái `draft/review/rejected/superseded/unpublished` không xuất hiện trong retrieval public mặc định |
| BR-04 | Tài liệu mới hơn **không tự động** thay thế bản cũ; phải có quan hệ supersession đã xác minh |
| BR-05 | Không đánh đồng ngày đăng bài với ngày hiệu lực hoặc hạn nộp hồ sơ |
| BR-06 | Dẫn nguồn phải liên kết evidence IDs thực sự được truy xuất, không để LLM tự dựng URL |
| BR-07 | Câu hỏi không đủ dữ liệu → `insufficient_evidence`, không suy luận ra số/chỉ tiêu/ngày |
| BR-08 | Năm được hỏi chưa công bố → nói rõ và có thể đưa số liệu năm cũ chỉ dưới nhãn lịch sử nếu hữu ích |
| BR-09 | Đầu vào từ trang web/tài liệu là **untrusted content**, không được thực thi như instruction cho AI |
| BR-10 | Dữ liệu người dùng không dùng đào tạo/cải thiện model ngoài phạm vi đã công bố/chấp thuận |

## 6. Acceptance scenarios (Given/When/Then)

| ID | Given | When | Then |
|---|---|---|---|
| AC-01 | Có nguồn 2026 đã publish | Hỏi phương thức ngành X năm 2026 | Trả lời đúng nguồn/citation và ghi rõ năm |
| AC-02 | Chỉ có nguồn 2026 | Hỏi học phí 2027 | Không khẳng định học phí 2027; cảnh báo thiếu nguồn |
| AC-03 | Hai nguồn mâu thuẫn, chưa review | Hỏi một hạn chót | Không tùy ý chọn một; trả về trạng thái cần xác minh |
| AC-04 | Tài liệu `draft` có dữ liệu khác | Public truy vấn | Không dùng evidence từ draft |
| AC-05 | Admin thu hồi phiên bản | Có truy vấn mới | Không trích dẫn bản bị thu hồi; giữ audit trail |
| AC-06 | PDF bảng có hàng/cột nhập nhằng | Admin kiểm duyệt | Gắn cảnh báo/không publish facts lỗi |
| AC-07 | Người dùng gửi prompt injection | Yêu cầu bỏ quy tắc, lộ prompt/API key | Không tiết lộ secret, không vượt scope |
| AC-08 | LLM timeout/budget exhausted | Người dùng hỏi | Hiển thị lỗi an toàn; không bịa đáp án |
| AC-09 | Người dùng nhập số điện thoại/CCCD | Hệ thống ghi log | Dữ liệu nhạy cảm được mask/không lưu raw mặc định |
| AC-10 | Citation từ tài liệu có đính kèm | Mở nguồn | Đến đúng URL nguồn ổn định; nếu không có deep-link, hiển thị trang tài liệu |

## 7. Non-functional requirements (NFR)

| ID | Nhóm | Yêu cầu/đích pilot |
|---|---|---|
| NFR-01 | Quality | Accuracy ≥95%, citation support ≥98%, abstention correctness ≥95% trên dataset gold (đề xuất) |
| NFR-02 | Retrieval | Recall@5 ≥90% trên tập câu hỏi có evidence được gắn nhãn (đề xuất) |
| NFR-03 | Performance | P95 TTFT ≤3 giây; đo ở điều kiện pilot ghi rõ tải/mô hình |
| NFR-04 | Availability | ≥99,5%/tháng là mục tiêu; đo sau deployment |
| NFR-05 | Accessibility | Keyboard navigation, focus rõ, contrast cơ bản; hướng WCAG 2.2 AA |
| NFR-06 | Security | HTTPS, admin RBAC, least privilege, rate limiting, secret management |
| NFR-07 | Privacy | Data minimization, log redaction, retention config, khả năng xóa khi có dữ liệu lưu |
| NFR-08 | Traceability | Answer trace: request → retrieval IDs → source version → model/prompt version |
| NFR-09 | Maintainability | Có migration, automated tests, runbook ingest/rollback, pin dependencies |
| NFR-10 | Cost | Token/embedding quota, budget alarm; ngân sách tối đa chờ Product Owner quyết định |

## 8. Nội dung câu trả lời và trạng thái UX

Response API phải phân biệt các trạng thái: `answered`, `clarification_needed`, `insufficient_evidence`, `conflicting_sources`, `out_of_scope`, `service_unavailable`. UI không đánh đồng chúng với lỗi 500. Khi có số liệu, ngày tháng, điều kiện, ưu tiên dẫn nguồn theo khẳng định hoặc cụm khẳng định; không gộp một nguồn chung gây hiểu lầm.

Trang public phải có cảnh báo dễ nhận thấy: “Đây là dự án hỗ trợ tra cứu độc lập, không phải kênh tuyển sinh chính thức của Trường Đại học An Giang. Vui lòng đối chiếu với thông báo từ nhà trường.” Câu chữ cuối cùng chờ review về pháp lý/thương hiệu.

## 9. Release gates và Definition of Done

- **Functionality:** FR P0 được demo qua E2E cho cả happy/error paths.
- **Data:** Có inventory tài liệu, QA report; không còn lỗi bảng/metadata quan trọng chưa xử lý ở published set.
- **AI eval:** Có ≥100 câu hỏi gồm năm/đợt, mã ngành, câu hỏi không có đáp án, tấn công; không phát hành nếu fail regression critical.
- **Security:** Admin API kiểm tra quyền, upload type/size, prompt-injection và rate-limit tests.
- **Operability:** Backup/restore được thử; rollback published snapshot, dashboard/logs hoạt động.
- **Review:** Người phát triển ký duyệt release checklist; phân biệt metric đã đạt và chưa đạt.

## 10. Dependencies và open decisions

1. **Nguồn:** Chốt tập tài liệu MVP, cơ chế bản quyền/điều kiện sử dụng trước khi public pilot.
2. **Chi phí:** Ngân sách cho LLM/embedding/hosting và traffic mục tiêu.
3. **Dữ liệu người dùng:** Chính sách lịch sử chat mặc định (đề xuất không lưu nội dung lâu dài ở MVP).
4. **Model:** Lựa chọn sau benchmark; không khóa nhà cung cấp trong code domain.
5. **UX:** Quyết định tên thương hiệu, disclaimer, kênh liên hệ công khai.

## 11. Traceability

- Module/routing: [`03-system-architecture.md`](03-system-architecture.md)
- Answer & retrieval contract: [`04-ai-rag-architecture.md`](04-ai-rag-architecture.md)
- Ingestion/version model: [`05-data-architecture.md`](05-data-architecture.md)
- UX states: [`06-ui-ux-specification.md`](06-ui-ux-specification.md)
- Delivery: [`08-implementation-roadmap.md`](08-implementation-roadmap.md)

