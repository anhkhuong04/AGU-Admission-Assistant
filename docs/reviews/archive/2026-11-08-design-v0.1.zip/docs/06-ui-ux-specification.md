# AGU Admission Assistant — UI/UX Design Specification

| Thuộc tính | Giá trị |
|---|---|
| Phiên bản | 0.1 — Draft for review |
| Ngày | 2026-11-08 |
| Định hướng | Education-first, trustworthy, responsive, accessibility-aware |
| Trạng thái | UX proposal; visual branding/hi-fidelity mockup chờ duyệt |

## 1. Experience goals

- Người dùng tìm thông tin **có kiểm chứng** trong ít thao tác, có thể bắt đầu không đăng nhập.
- Không ép mọi tác vụ vào khung chat: danh mục ngành, bộ lọc, FAQ và hướng dẫn có giao diện riêng.
- Nguồn, năm tuyển sinh và giới hạn thông tin phải **nhìn thấy tại điểm đọc**, không giấu ở cuối trang.
- UI phản ánh trạng thái hệ thống thực, không tạo cảm giác AI luôn chắc chắn.
- Dùng văn phong tiếng Việt rõ, bình tĩnh, hữu ích; tránh slogan sáo rỗng và các chỉ số tự bịa.

## 2. Information architecture

```text
Public
  /                  Home: định hướng + lối tắt + chat entry
  /assistant         Chat đầy đủ; sources panel; session context
  /admissions        Thông tin tuyển sinh theo năm (P1 nếu dữ liệu đủ)
  /majors            Danh sách ngành; search/filter (P1)
  /majors/[slug]     Chi tiết ngành, nguồn theo thuộc tính (P1)
  /compare           So sánh 2–3 ngành (P1)
  /help              FAQ, chính sách dữ liệu, link AGU
  /about             Giới thiệu dự án độc lập / disclaimer

Admin (authenticated)
  /admin             Metrics, warnings, latest ingestion
  /admin/sources     Sources, files, statuses, versions
  /admin/review/[id] Side-by-side original vs extraction + publish
  /admin/evaluation Dataset/runs/errors
  /admin/settings   Roles, provider config metadata, quotas
```

**MVP navigation:** Home, Assistant, Help, About; admin Sources/Review/Evaluation tối giản. `Admissions`/`Majors` có thể dùng landing page liên kết nguồn nếu dữ liệu structured chưa đủ chuẩn; không xây những trang trống.

## 3. Primary user flows

### U1 — First-time visitor

Home → chọn “Hỏi về phương thức xét tuyển” hoặc nhập câu hỏi → chatbot yêu cầu năm nếu cần → câu trả lời có citation → mở nguồn → optional feedback.

### U2 — Question is not answerable

Chat → evidence không đủ → thông báo “Chưa tìm thấy thông tin được xác minh cho năm ...” → link cổng AGU / câu hỏi gợi ý có phạm vi đúng → không tự phỏng đoán.

### U3 — Admin publishes a corrected document

Sources → upload/URL → processing state → review raw/parsed/metadata → sửa lỗi/approve → index readiness → publish → kiểm thử câu hỏi mẫu → nếu lỗi rollback.

## 4. Page specifications

### 4.1 Home `/`

- **Hero:** “Bạn cần tìm hiểu điều gì về tuyển sinh AGU?”; một ô nhập câu hỏi chính, không hình minh họa AI chiếm diện tích vô nghĩa.
- **Quick actions:** Ngành học, Phương thức xét tuyển, Học phí, Mốc thời gian — chỉ hiện nếu nguồn đã được duyệt/đường dẫn hoạt động.
- **Trust note:** dự án độc lập; dữ liệu có thể thay đổi; link official portal.
- **Latest verified source** (optional): chỉ hiển thị từ collection thực, không viết cứng “mới nhất”.
- **No fake social proof:** không hiển thị “99,9% chính xác”, số sinh viên/đánh giá không có số liệu.

### 4.2 AI Assistant `/assistant`

- Layout desktop: navigation + transcript chính + panel nguồn có thể collapse. Mobile: transcript full width, sources trong bottom sheet/dialog.
- Input multiline, submit rõ ràng, có nút stop khi streaming, hiển thị loading/TTFT.
- Session year selector; nếu chưa chọn, chatbot hỏi lại khi cần; năm đang áp dụng hiện trên câu trả lời.
- Answer UI: tóm tắt trước, bullets cho các bước, inline citation refs; mở source drawer chứa title, năm, loại, ngày xuất bản, page/section, URL nguồn.
- State cards: `clarification_needed`, `insufficient_evidence`, `conflicting_sources`, `out_of_scope`, `service_unavailable` với nội dung khác nhau.
- Feedback: “Hữu ích” / “Chưa chính xác” + reason optional, không yêu cầu định danh.
- Chỉ bật lưu lịch sử khi có chính sách/consent và chức năng xóa phù hợp.

### 4.3 Majors `/majors` (P1)

- Search tên/mã ngành, bộ lọc theo năm, danh sách có trạng thái số liệu thiếu.
- Cards/table chuyển theo viewport; tiêu chí so sánh chỉ dùng facts verified.
- Mỗi số liệu nhạy cảm có nguồn hoặc CTA “Xem thông báo AGU”; tránh thẻ thông tin giả đầy đủ.

### 4.4 Admin `/admin/sources`, `/admin/review/[id]`

- Status chip: Discovered, Parsed, Needs Review, Approved, Indexed, Published, Failed, Superseded.
- Review screen: bản gốc (PDF/page) bên trái, structured extraction bên phải, thay đổi metadata và warnings; publish là hành động xác nhận riêng.
- Hiển thị ảnh hưởng khi thay thế: chunk/fact counts, năm/đợt, quan hệ supersedes, QA outcome.
- Rollback yêu cầu confirm và ghi audit reason; không dùng nút “Delete” cho bản đang published.

## 5. UI state matrix

| State | Nội dung hiển thị | User action |
|---|---|---|
| Idle | Prompt gợi ý nội dung thực | Nhập câu hỏi |
| Retrieving | Skeleton/progress nhẹ, không giả câu trả lời | Có thể stop |
| Streaming | Văn bản tăng dần; citation khi finalized | Đọc/chờ |
| Answered | Nội dung + năm/đợt + source links | Mở source/feedback |
| Clarify | Một câu hỏi làm rõ cụ thể | Chọn năm/ngành |
| Insufficient | Nêu dữ liệu chưa xác minh | Truy cập nguồn chính thức |
| Conflict | Cảnh báo tài liệu xung đột, không kết luận | Xem nguồn/liên hệ trường |
| Error/offline | Thông báo trung thực + retry | Thử lại |
| Rate limited | Nêu chờ thử lại, không lộ cấu hình | Thử lại sau |
| Mobile source | Drawer/bottom sheet có focus trap | Đóng/mở trích dẫn |

## 6. Design language

- Hướng thị giác: **Academic Minimalist + Fluent 2-inspired**; dùng tokens màu, spacing, radius, typography nhất quán.
- Palette: nền neutral/sáng, accent xanh dương; màu đỏ chỉ cho lỗi/xung đột, xanh lá cho trạng thái xác nhận. **Không mặc định màu logo/chính thức của AGU** nếu chưa được cho phép.
- Typography: sans-serif hỗ trợ tiếng Việt và dấu đầy đủ; body ≥16px mobile, line-height 1.45–1.6.
- Spacing: thang 4/8px; grid 12 cột desktop, 4 cột mobile; content width hội thoại để dễ đọc.
- Components: Navigation, Search/Prompt input, Chat bubble, Source citation, Status alert, Year selector, Major card, Comparison table, Admin data grid.
- Dùng design tokens thay vì hardcode màu lặp; light mode trước, dark mode optional sau.
- Tránh glassmorphism, gradients dày đặc, emoji tùy hứng, hero 3D không liên quan, animation làm nhiễu.

## 7. Responsive & accessibility

- Breakpoints đề xuất: `<640px` mobile, `640–1023px` tablet, `≥1024px` desktop; kiểm tra viewport hẹp 320px.
- Keyboard: tab order đúng, skip link, Enter gửi/Shift+Enter xuống dòng, focus visible; không làm mất nội dung khi resize.
- Screen reader: semantic headings, label cho input, `aria-live` cập nhật phù hợp streaming (tránh đọc từng token), mở source bằng dialog có focus management.
- Contrast mục tiêu WCAG 2.2 AA; touch target đủ lớn; tôn trọng `prefers-reduced-motion`.
- Không dùng màu để truyền đạt trạng thái duy nhất; text/icon đi kèm.
- Link ngoài thể hiện domain và mở nguồn chính thức rõ ràng.

## 8. Content / microcopy policy

| Tình huống | Microcopy gợi ý |
|---|---|
| Khởi đầu | “Bạn muốn tìm hiểu ngành học, phương thức xét tuyển hay hồ sơ?” |
| Thiếu năm | “Bạn đang hỏi về tuyển sinh năm nào?” |
| Không đủ nguồn | “Mình chưa tìm thấy nguồn được xác minh cho thông tin này.” |
| Xung đột | “Có các tài liệu chưa thống nhất. Mình chưa thể kết luận chắc chắn.” |
| Phụ thuộc lịch sử | “Dữ liệu dưới đây thuộc năm 2026, không phải quy định năm 2027.” |
| Disclaimer | “Đây là công cụ tra cứu độc lập, không phải kênh tư vấn chính thức của AGU.” |

Microcopy không được hứa “chính xác tuyệt đối”, không thúc ép thí sinh chọn ngành, không nhân danh cán bộ tuyển sinh.

## 9. UX acceptance tests

1. Người dùng mobile hoàn thành 5 tác vụ tìm nguồn mà không cần tạo tài khoản.
2. Trong câu hỏi theo năm, UI thể hiện chính xác năm đang áp dụng hoặc hỏi làm rõ.
3. Source link có tiêu đề và mở được nguồn; khi deep link PDF không sẵn có, hiển thị page/section trong UI.
4. Trạng thái không đủ dữ liệu và xung đột phân biệt được với lỗi mạng.
5. Dùng bàn phím và screen reader điều hướng được chat/source/admin forms.
6. Không có dữ liệu số liệu/thống kê giả, placeholder được đánh dấu minh họa.
7. Tối thiểu 5 người dùng thử pilot; log vấn đề UX và sửa lỗi critical trước public launch.

## 10. Deliverables cho implementation

- Sitemap/routes và page-state map (tài liệu này).
- UI tokens + component inventory, Figma/mockups sau khi chốt visual branding.
- Responsive annotated wireframes Home, Assistant, Admin Review trước khi coding.
- Functional contracts từ [`02-prd.md`](02-prd.md) và API từ [`03-system-architecture.md`](03-system-architecture.md).

